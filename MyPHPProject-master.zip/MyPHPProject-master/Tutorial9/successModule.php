<?php 
include("../HeaderNav.php"); 
?>

<div class="container pb-5">
    <main role="main" class="pb-3">
        <h2>Module Creation Successful!</h2><br>
        
      
    </main>
</div>



<?php
    include("../Footer.php"); 
?>