<?php 
    include("../Nav/Admin/loggedHeaderAdmin.php");
    

?>
<div class="container pb-5">
    <main role="main">
        <div>Successfull Created a Module!</div>
    </main>
</div>

<?php 
    include("../Nav/loggedFooter.php");
?>