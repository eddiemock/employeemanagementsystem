<?php 

$fname = "Zairul";
$lname = "Mazwan";

echo "Hello ".$fname." ".$lname;

?>