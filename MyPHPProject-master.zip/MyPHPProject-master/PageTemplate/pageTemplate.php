<?php 
include("../HeaderNav.php"); 
?>

<div class="container pb-5">
    <main role="main" class="pb-3">
        <h2>Page Template</h2><br>
        
        WRITE YOUR CONTENT HERE!!!


    </main>
</div>



<?php
    include("../Footer.php"); 
?>